#!/system/bin/sh
#NezukaInstallation
LOCALE=$(getprop persist.sys.locale)
[ -z "$LOCALE" ] && LOCALE=$(getprop ro.product.locale)
[ -z "$LOCALE" ] && LOCALE=$(getprop ro.product.locale.language)

case "$LOCALE" in
  id*|in*) LANG_ID=1 ;;
  *)       LANG_ID=0 ;;
esac

T() {
  [ "$LANG_ID" -eq 1 ] && echo "$1" || echo "$2"
}

loading() {
  local teks="$1" i=0 j bar
  while [ $i -le 10 ]; do
    bar=""
    j=0
    while [ $j -lt 10 ]; do
      [ $j -lt $i ] && bar="${bar}■" || bar="${bar}□"
      j=$((j+1))
    done
    ui_print "  [$bar] $((i*10))%  $teks"
    sleep 0.5
    i=$((i+1))
  done
}

cek_perangkat() {
  ui_print " "
  ui_print "$(T "- Memeriksa perangkat..." "- Checking device...")"
  loading "$(T "Membaca info sistem" "Reading system info")"

  local api brand manuf ver trans_prop is_trans=0
  api=$(getprop ro.build.version.sdk)
  ver=$(getprop ro.build.version.release)
  brand=$(getprop ro.product.brand | tr 'A-Z' 'a-z')
  manuf=$(getprop ro.product.manufacturer | tr 'A-Z' 'a-z')
  trans_prop=$(getprop | grep -i -E "tranos|transsion" | head -n 1)

  loading "$(T "Memeriksa versi Android" "Checking Android version")"
  if [ "$api" -ne 36 ]; then
    ui_print " "
    ui_print "$(T "- Gagal: modul ini hanya untuk Android 16!" "- Failed: this module is for Android 16 only!")"
    ui_print "$(T "- Versi kamu: Android $ver (API $api)" "- Your version: Android $ver (API $api)")"
    abort "$(T "- Instalasi dibatalkan." "- Installation cancelled.")"
  fi

  loading "$(T "Memeriksa Transsion OS" "Checking Transsion OS")"
  case "$brand $manuf" in
    *tecno*|*infinix*|*itel*|*transsion*) is_trans=1 ;;
  esac
  [ -n "$trans_prop" ] && is_trans=1

  if [ "$is_trans" -ne 1 ]; then
    ui_print " "
    ui_print "$(T "- Gagal: modul ini hanya untuk Transsion OS (HiOS, XOS, itelOS)!" "- Failed: this module is for Transsion OS only (HiOS, XOS, itelOS)!")"
    ui_print "$(T "- Perangkat terdeteksi: $brand / $manuf" "- Detected device: $brand / $manuf")"
    abort "$(T "- Instalasi dibatalkan." "- Installation cancelled.")"
  fi

  ui_print " "
  ui_print "$(T "- Perangkat didukung: Android $ver, Transsion OS" "- Device supported: Android $ver, Transsion OS")"
  sleep 1
}

pertahankan_dynbar() {
  local key="ro.os_dynamic_bar_resident_plane_support"
  local nezdir=/data/adb/nez_noapps
  local oldprop="/data/adb/modules/${MODID:-TOS_Unlock}/system.prop"
  local off=0

  if [ -f "$oldprop" ] && grep -q "^$key=" "$oldprop"; then
    if grep -q "^$key=0" "$oldprop"; then off=1; else rm -f "$nezdir/dynbar_off"; fi
  else
      [ -f "$nezdir/dynbar_off" ] && off=1
  fi

  if [ "$off" = 1 ]; then
    mkdir -p "$nezdir"
    touch "$nezdir/dynbar_off"
    [ -f "$MODPATH/system.prop" ] && sed -i "s/^$key=.*/$key=0/" "$MODPATH/system.prop"
    ui_print " "
    ui_print "$(T "- Always Dynamic Bar: OFF (dipertahankan dari versi sebelumnya)" "- Always Dynamic Bar: OFF (kept from the previous version)")"
  fi
}

pilih() {
  local ev
  ev=$(timeout 30 getevent -lq 2>/dev/null | grep -m1 -E "KEY_VOLUME(UP|DOWN) +DOWN")
  case "$ev" in
    *KEY_VOLUMEUP*)   return 0 ;;
    *KEY_VOLUMEDOWN*) return 1 ;;
    *)                return 2 ;;
  esac
}

tanya() {
  ui_print " "
  ui_print "$(T "$1" "$2")"
  ui_print "  $(T "Volume Atas   = Ya" "Volume Up     = Yes")"
  ui_print "  $(T "Volume Bawah  = Tidak" "Volume Down   = No")"
  pilih
  local r=$?
  [ $r -eq 2 ] && abort "$(T "- Tidak ada jawaban 30 detik, instalasi dibatalkan." "- No answer in 30 seconds, installation cancelled.")"
  return $r
}

YA=$(T "Ya" "Yes")
TIDAK=$(T "Tidak" "No")

cek_perangkat
pertahankan_dynbar

PILIH_ADA=0
mkdir -p "$MODPATH/system/product/overlay"

if tanya "1. Inginkah Anda menyalakan Launcher Blur?" "1. Do you want to enable Launcher Blur?"; then
  ui_print "  > Launcher Blur: $YA"
  cp -af "$MODPATH/NezAssets/." "$MODPATH/system/"
  PILIH_ADA=1
else
  ui_print "  > Launcher Blur: $TIDAK"
fi

if tanya "2. Inginkah Anda memasang Rounded Dynamic Bar?" "2. Do you want to install Rounded Dynamic Bar?"; then
  ui_print "  > Rounded Dynamic Bar: $YA"
  cp -af "$MODPATH/NezOverlay/product/overlay/DynamicBarPill.apk" \
         "$MODPATH/system/product/overlay/"
  PILIH_ADA=1
else
  ui_print "  > Rounded Dynamic Bar: $TIDAK"
fi

if tanya "3. Inginkah Anda memasang Bigger Dock Icon?" "3. Do you want to install Bigger Dock Icon?"; then
  ui_print "  > Bigger Dock Icon: $YA"
  cp -af "$MODPATH/NezOverlay/product/overlay/HotseatIcon.apk" \
         "$MODPATH/system/product/overlay/"
  PILIH_ADA=1
else
  ui_print "  > Bigger Dock Icon: $TIDAK"
fi

if [ "$PILIH_ADA" -eq 0 ]; then
  abort "$(T "- Tidak ada fitur yang dipilih, instalasi dibatalkan." "- No feature selected, installation cancelled.")"
fi

rm -rf "$MODPATH/NezAssets" "$MODPATH/NezOverlay"
rmdir "$MODPATH/system/product/overlay" 2>/dev/null
rmdir "$MODPATH/system/product" 2>/dev/null

ui_print " "
ui_print "$(T "- Mengatur perizinan..." "- Setting permissions...")"

set_perm_recursive "$MODPATH/system" 0 0 0755 0644 u:object_r:system_file:s0

if [ -d "$MODPATH/system/product/overlay" ]; then
  set_perm_recursive "$MODPATH/system/product/overlay" 0 0 0755 0644 u:object_r:system_file:s0
fi

if [ -d "$MODPATH/system/tr_product" ]; then
  set_perm_recursive "$MODPATH/system/tr_product" 0 0 0755 0644 u:object_r:system_file:s0
fi

[ -d "$MODPATH/NezScript" ] && set_perm_recursive "$MODPATH/NezScript" 0 0 0755 0755
[ -d "$MODPATH/webroot" ]   && set_perm_recursive "$MODPATH/webroot" 0 0 0755 0644
[ -f "$MODPATH/service.sh" ]   && set_perm "$MODPATH/service.sh" 0 0 0755
[ -f "$MODPATH/customize.sh" ] && set_perm "$MODPATH/customize.sh" 0 0 0755

ui_print " "
ui_print "$(T "- Instalasi selesai. Silakan reboot." "- Installation complete. Please reboot.")"