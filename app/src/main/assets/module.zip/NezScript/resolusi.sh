#!/system/bin/sh
# Nez Resolusi: ubah resolusi layar dengan pengaman auto-kembali
# Pemakaian: resolusi.sh info | apply <persen> | confirm | revert | reset | failsafe <token>

DIR=/data/adb/nez_noapps
PREV=$DIR/res_prev
PEND=$DIR/res_pending
FS_SEC=25
mkdir -p "$DIR"

clean()     { tr -d ' \r'; }
size_phys() { wm size 2>/dev/null    | grep -i "Physical size"    | sed 's/.*: *//' | clean; }
size_over() { wm size 2>/dev/null    | grep -i "Override size"    | sed 's/.*: *//' | clean; }
den_phys()  { wm density 2>/dev/null | grep -i "Physical density" | sed 's/.*: *//' | clean; }
den_over()  { wm density 2>/dev/null | grep -i "Override density" | sed 's/.*: *//' | clean; }

info() {
  ps=$(size_phys); cs=$(size_over); [ -z "$cs" ] && cs=$ps
  pd=$(den_phys);  cd=$(den_over);  [ -z "$cd" ] && cd=$pd
  echo "PSIZE=$ps"
  echo "CSIZE=$cs"
  echo "PDEN=$pd"
  echo "CDEN=$cd"
  left=0
  if [ -f "$PEND" ]; then
    st=$(cut -d_ -f1 "$PEND")
    case "$st" in
      ''|*[!0-9]*) left=0 ;;
      *) left=$(( FS_SEC - ($(date +%s) - st) )); [ "$left" -lt 0 ] && left=0 ;;
    esac
  fi
  echo "LEFT=$left"
}

# calc <persen> -> "LxT D"
calc() {
  ps=$(size_phys); pd=$(den_phys)
  W=${ps%x*}; H=${ps#*x}
  case "$W$H$pd" in ''|*[!0-9]*) return 1 ;; esac
  nw=$(( (W * $1 + 50) / 100 )); nh=$(( (H * $1 + 50) / 100 ))
  nw=$(( nw / 2 * 2 ));          nh=$(( nh / 2 * 2 ))
  nd=$(( (pd * $1 + 50) / 100 ))
  echo "${nw}x${nh} $nd"
}

revert() {
  ps=$(grep '^PS=' "$PREV" 2>/dev/null | cut -d= -f2-)
  pd=$(grep '^PD=' "$PREV" 2>/dev/null | cut -d= -f2-)
  if [ -n "$ps" ]; then wm size "$ps"; else wm size reset; fi
  if [ -n "$pd" ]; then wm density "$pd"; else wm density reset; fi
  rm -f "$PEND"
}

apply() {
  pct=$1
  case "$pct" in ''|*[!0-9]*) echo "ERR pct"; exit 1 ;; esac
  if [ "$pct" -lt 40 ] || [ "$pct" -gt 130 ]; then echo "ERR range"; exit 1; fi

  out=$(calc "$pct") || { echo "ERR calc"; exit 1; }
  set -- $out
  size=$1; den=$2

  # simpan kondisi sebelumnya (kosong = tidak ada override)
  prevsize=$(size_over)
  prevden=$(den_over)
  printf 'PS=%s\nPD=%s\n' "$prevsize" "$prevden" > "$PREV"

  tok="$(date +%s)_$$"
  echo "$tok" > "$PEND"

  if [ "$pct" = 100 ]; then
    wm size reset; wm density reset
  else
    wm size "$size"; wm density "$den"
  fi

  # pengaman: kembali otomatis jika tidak dikonfirmasi
  nohup sh "$0" failsafe "$tok" >/dev/null 2>&1 &
  echo "OK $size $den"
}

confirm() { rm -f "$PEND"; }

reset() {
  wm size reset
  wm density reset
  rm -f "$PEND" "$PREV"
}

failsafe() {
  sleep "$FS_SEC"
  [ -f "$PEND" ] && [ "$(cat "$PEND")" = "$1" ] && revert
}

case "$1" in
  info)     info ;;
  apply)    apply "$2" ;;
  confirm)  confirm ;;
  revert)   revert ;;
  reset)    reset ;;
  failsafe) failsafe "$2" ;;
  *)        echo "pakai: resolusi.sh info|apply <persen>|confirm|revert|reset" ;;
esac