#!/system/bin/sh
# Nez Debloat - hapus aplikasi sistem untuk pengguna 0 (bisa dipulihkan)
# Pemakaian: debloat.sh list | removed | remove <pkg...> | restore <pkg...> | backup

DIR=/data/adb/nez_noapps
LOG=$DIR/debloat_removed.txt
mkdir -p "$DIR"
touch "$LOG"

valid() {
  case "$1" in ''|*[!A-Za-z0-9._]*) return 1 ;; esac
  return 0
}

# Daftar terlarang (pengaman lapis kedua, selain di tampilan)
denied() {
  case "$1" in
    android|com.android.se) return 0 ;;
    android.*|com.android.systemui*|com.android.settings*|com.android.phone*|com.android.server.telecom*|\
    com.android.providers.*|com.android.bluetooth*|com.android.nfc*|com.android.shell*|\
    com.android.inputmethod*|com.android.permissioncontroller*|com.android.packageinstaller*|\
    com.android.vending*|com.android.webview*|com.android.networkstack*|com.android.location*|\
    com.android.keychain*|com.android.certinstaller*|com.android.cellbroadcast*|com.android.emergency*|\
    com.android.stk*|com.android.mms.service*|com.android.carrierconfig*|com.android.managedprovisioning*|\
    com.android.documentsui*|com.android.externalstorage*|com.android.mtp*|com.android.wallpaper*|\
    com.android.companiondevicemanager*|com.android.internal.*|\
    com.google.android.gms*|com.google.android.gsf*|com.google.android.setupwizard*|\
    com.google.android.webview*|com.google.android.permissioncontroller*|\
    com.google.android.packageinstaller*|com.google.android.networkstack*|com.google.android.ext.*|\
    com.google.android.captiveportallogin*|me.weishu.kernelsu*|com.topjohnwu.magisk*|\
    com.rifsxd.ksunext*|com.sukisu*|io.github.a13e300.ksuwebui*|com.dergoogler.mmrl*|\
    com.mediatek.*|com.qualcomm.*|com.sprd.*|com.unisoc.*|\
    *launcher*|*systemui*|*telecom*|*telephony*|*keyguard*|*.overlay|*.overlay.*|*auto_generated_rro*|\
    *.ims|*.ims.*)
      return 0 ;;
  esac
  [ -n "$HOME_PKG" ] && [ "$1" = "$HOME_PKG" ] && return 0
  [ -n "$IME_PKG" ]  && [ "$1" = "$IME_PKG" ]  && return 0
  return 1
}

init_guard() {
  HOME_PKG=$(cmd package resolve-activity --brief -c android.intent.category.HOME \
    -a android.intent.action.MAIN 2>/dev/null | tail -n 1 | cut -d/ -f1)
  IME_PKG=$(settings get secure default_input_method 2>/dev/null | cut -d/ -f1)
  [ "$IME_PKG" = null ] && IME_PKG=""
}

do_list() {
  pm list packages -s 2>/dev/null | sed 's/^package://' | sort
}

do_removed() {
  pm list packages -s -u 2>/dev/null | sed 's/^package://' | sort > "$DIR/.d_all"
  pm list packages -s 2>/dev/null    | sed 's/^package://' | sort > "$DIR/.d_in"
  comm -23 "$DIR/.d_all" "$DIR/.d_in"
  rm -f "$DIR/.d_all" "$DIR/.d_in"
}

do_remove() {
  init_guard
  for p in "$@"; do
    if ! valid "$p"; then echo "BAD $p"; continue; fi
    if denied "$p"; then echo "DENY $p"; continue; fi
    if pm uninstall -k --user 0 "$p" 2>&1 | grep -q Success; then
      grep -qx "$p" "$LOG" || echo "$p" >> "$LOG"
      echo "OK $p"
    else
      echo "FAIL $p"
    fi
  done
}

do_restore() {
  for p in "$@"; do
    if ! valid "$p"; then echo "BAD $p"; continue; fi
    if cmd package install-existing --user 0 "$p" 2>&1 | grep -qi "installed for user"; then
      sed -i "/^$p\$/d" "$LOG" 2>/dev/null
      echo "OK $p"
    else
      echo "FAIL $p"
    fi
  done
}

do_backup() {
  out=/sdcard/Download/nez_debloat_backup.txt
  { echo "# Nez Debloat - aplikasi yang dihapus untuk user 0"; do_removed; } > "$out" 2>/dev/null
  echo "OK $out"
}

cmd_=$1
[ $# -gt 0 ] && shift
case "$cmd_" in
  list)    do_list ;;
  removed) do_removed ;;
  remove)  do_remove "$@" ;;
  restore) do_restore "$@" ;;
  backup)  do_backup ;;
  *)       echo "pakai: debloat.sh list|removed|remove <pkg...>|restore <pkg...>|backup" ;;
esac