#!/system/bin/sh
# Nez Tweaks - semua chipset MediaTek (Helio, Dimensity, dll)
# Pemakaian: tweaks.sh apply|boot|reset|info|stat|hzlist|ramclean|killbg|trimcache|fstrim|dexopt|junk

DIR=/data/adb/nez_noapps
CONF=$DIR/tweaks.conf
ORIG=$DIR/tweaks_orig.conf
mkdir -p "$DIR"
touch "$CONF" "$ORIG"

cfg()   { grep -m1 "^$1=" "$CONF" 2>/dev/null | cut -d= -f2-; }
oget()  { grep -m1 "^$1=" "$ORIG" 2>/dev/null | cut -d= -f2-; }
osave() { grep -q "^$1=" "$ORIG" 2>/dev/null || echo "$1=$2" >> "$ORIG"; }

# setv <file> <nilai> <kunci>: simpan nilai asli lalu tulis nilai baru
setv() {
  [ -w "$1" ] || return 1
  osave "$3" "$(cat "$1" 2>/dev/null)"
  echo "$2" > "$1" 2>/dev/null
}
# restv <file> <kunci>: kembalikan nilai asli (jika pernah disimpan)
restv() {
  [ -w "$1" ] || return 1
  v=$(oget "$2")
  [ -n "$v" ] && echo "$v" > "$1" 2>/dev/null
}
# mset <1|0> <file> <nilai> <kunci>
mset() {
  if [ "$1" = 1 ]; then setv "$2" "$3" "$4"; else restv "$2" "$4"; fi
}

# ---------- Deteksi MediaTek (Helio, Dimensity, dll) ----------
PLAT=$(getprop ro.board.platform)
HW=$(getprop ro.hardware)
SOCMODEL=$(getprop ro.soc.model)
SOCSTR="$(getprop ro.soc.manufacturer) $SOCMODEL $PLAT $HW $(getprop ro.mediatek.platform) $(getprop ro.vendor.mediatek.platform)"
if echo "$SOCSTR" | grep -qiE "mediatek|mt[0-9]{4}"; then MT=1; else MT=0; fi
SOC=${SOCMODEL:-$PLAT}

# ---------- Animasi ----------
anim_apply() {
  a=$(cfg ANIM)
  case "$a" in 1.0|0.5|0.3|0) ;; *) return ;; esac
  for k in window_animation_scale transition_animation_scale animator_duration_scale; do
    settings put global $k "$a"
  done
}

# ---------- Blur jendela ----------
blur_apply() {
  b=$(cfg BLUR)
  case "$b" in 0|1) settings put global disable_window_blurs "$b" ;; esac
}

# ---------- Pemindaian latar belakang Wi-Fi & Bluetooth ----------
scan_apply() {
  s=$(cfg SCAN)
  case "$s" in
    1)
      osave scan_wifi "$(settings get global wifi_scan_always_enabled 2>/dev/null)"
      osave scan_ble  "$(settings get global ble_scan_always_enabled 2>/dev/null)"
      settings put global wifi_scan_always_enabled 0
      settings put global ble_scan_always_enabled 0
      ;;
    0)
      for k in wifi ble; do
        v=$(oget "scan_$k")
        [ -z "$v" ] && continue
        if [ "$v" = null ]; then
          settings delete global ${k}_scan_always_enabled >/dev/null 2>&1
        else
          settings put global ${k}_scan_always_enabled "$v"
        fi
      done
      ;;
  esac
}

# ---------- Renderer (berlaku untuk proses aplikasi yang baru dibuka) ----------
render_apply() {
  r=$(cfg RENDER)
  case "$r" in
    skiagl|skiavk) setprop debug.hwui.renderer "$r" ;;
    default)       setprop debug.hwui.renderer "" ;;
  esac
}

# ---------- Refresh rate ----------
hz_apply() {
  h=$(cfg HZ)
  case "$h" in
    default) ;;
    ''|*[!0-9]*) return ;;
    *) { [ "$h" -ge 30 ] && [ "$h" -le 240 ]; } || return ;;
  esac
  osave hz_min  "$(settings get system min_refresh_rate 2>/dev/null)"
  osave hz_peak "$(settings get system peak_refresh_rate 2>/dev/null)"
  if [ "$h" = default ]; then
    for k in min peak; do
      v=$(oget "hz_$k")
      if [ -z "$v" ] || [ "$v" = null ]; then
        settings delete system ${k}_refresh_rate >/dev/null 2>&1
      else
        settings put system ${k}_refresh_rate "$v"
      fi
    done
  else
    settings put system min_refresh_rate "$h"
    settings put system peak_refresh_rate "$h"
  fi
}

hz_list() {
  dumpsys display 2>/dev/null | grep -oE "fps=[0-9]+(\.[0-9]+)?" | sed 's/fps=//' | cut -d. -f1 \
    | grep -E '^(4[89]|[5-9][0-9]|1[0-9][0-9]|2[0-4][0-9])$' | sort -un | tr '\n' ' '
}

# ---------- Profil CPU: semua cluster (policy*) otomatis ----------
cpu_apply() {
  [ "$MT" = 1 ] || return
  prof=$(cfg PROFILE); [ -z "$prof" ] && prof=std
  for p in /sys/devices/system/cpu/cpufreq/policy*; do
    [ -d "$p" ] || continue
    n=${p##*/}
    g=$p/scaling_governor

    if [ "$prof" = perf ]; then
      grep -qw performance "$p/scaling_available_governors" 2>/dev/null && setv "$g" performance "gov_$n"
    else
      restv "$g" "gov_$n"
    fi

    # Batas laju schedutil: lebih cepat naik pada profil Responsif
    for f in up_rate_limit_us rate_limit_us; do
      nf=$p/schedutil/$f
      [ -e "$nf" ] || continue
      if [ "$prof" = resp ]; then setv "$nf" 500 "rl_${n}_$f"; else restv "$nf" "rl_${n}_$f"; fi
    done
    nf=$p/schedutil/down_rate_limit_us
    if [ -e "$nf" ]; then
      if [ "$prof" = resp ]; then setv "$nf" 20000 "dl_$n"; else restv "$nf" "dl_$n"; fi
    fi
  done
}

# ---------- Profil GPU (Mali, jika terekspos lewat devfreq) ----------
gpu_apply() {
  [ "$MT" = 1 ] || return
  prof=$(cfg PROFILE); [ -z "$prof" ] && prof=std
  for d in /sys/class/devfreq/*mali* /sys/class/devfreq/*gpu*; do
    [ -d "$d" ] || continue
    n=$(basename "$d" | tr -c 'A-Za-z0-9\n' '_')
    g=$d/governor
    if [ "$prof" = perf ] && grep -qw performance "$d/available_governors" 2>/dev/null; then
      setv "$g" performance "ggov_$n"
    else
      restv "$g" "ggov_$n"
    fi
  done
}

# ---------- Memori & I/O ----------
mem_apply() {
  m=$(cfg MEM)
  case "$m" in 0|1) ;; *) return ;; esac
  mset "$m" /proc/sys/vm/dirty_ratio 20 vm_dr
  mset "$m" /proc/sys/vm/dirty_background_ratio 10 vm_dbr
  mset "$m" /proc/sys/vm/vfs_cache_pressure 80 vm_vcp
  for q in /sys/block/sd?/queue /sys/block/mmcblk0/queue; do
    [ -d "$q" ] || continue
    b=$(basename "$(dirname "$q")")
    mset "$m" "$q/read_ahead_kb" 128 "ra_$b"
    mset "$m" "$q/iostats" 0 "ios_$b"
    mset "$m" "$q/add_random" 0 "ar_$b"
  done
}

apply_all() {
  anim_apply
  blur_apply
  scan_apply
  render_apply
  hz_apply
  cpu_apply
  gpu_apply
  mem_apply
}

# ---------- Perawatan ----------
do_fstrim() {
  if command -v fstrim >/dev/null 2>&1; then
    for m in /data /cache /metadata; do
      [ -d "$m" ] && fstrim -v "$m" 2>/dev/null
    done
  else
    sm idle-maint run >/dev/null 2>&1
  fi
}

junk_clean() {
  logcat -b all -c 2>/dev/null
  rm -rf /data/anr/* /data/tombstones/* 2>/dev/null
  return 0
}

# Dipanggil saat boot: terapkan tweak + perawatan otomatis tiap 7 hari
boot_all() {
  apply_all
  if [ "$(cfg AUTOCLEAN)" = 1 ]; then
    last=$(cat "$DIR/last_clean" 2>/dev/null)
    case "$last" in ''|*[!0-9]*) last=0 ;; esac
    now=$(date +%s)
    if [ $((now - last)) -ge 604800 ]; then
      echo "$now" > "$DIR/last_clean"
      ( sleep 120; pm trim-caches 999G >/dev/null 2>&1; do_fstrim >/dev/null 2>&1 ) >/dev/null 2>&1 &
    fi
  fi
}

reset_all() {
  printf '%s\n' "ANIM=1.0" "BLUR=0" "SCAN=0" "RENDER=default" "HZ=default" "PROFILE=std" "MEM=0" "AUTOCLEAN=0" > "$CONF"
  apply_all
  rm -f "$CONF" "$ORIG"
}

# info: ringan (tanpa dumpsys). Daftar refresh rate diminta terpisah lewat "hzlist".
info() {
  echo "SOC=$SOC"
  echo "PLAT=$PLAT"
  echo "HW=$HW"
  echo "MT=$MT"
  p=/sys/devices/system/cpu/cpufreq/policy0
  echo "GOV=$(cat $p/scaling_governor 2>/dev/null)"
  echo "AVAIL=$(cat $p/scaling_available_governors 2>/dev/null)"
  for d in /sys/class/devfreq/*mali* /sys/class/devfreq/*gpu*; do
    [ -d "$d" ] && { echo "GGOV=$(cat $d/governor 2>/dev/null)"; break; }
  done
  echo "REND=$(getprop debug.hwui.renderer)"
  echo "ANIM=$(settings get global window_animation_scale 2>/dev/null)"
  echo "HZPEAK=$(settings get system peak_refresh_rate 2>/dev/null)"
}

# ---------- Statistik untuk Monitor ----------
mem_kb() { grep -m1 "^$1:" /proc/meminfo | tr -s ' ' | cut -d' ' -f2; }

stat_all() {
  echo "MEMT=$(mem_kb MemTotal)"
  echo "MEMA=$(mem_kb MemAvailable)"
  echo "SWAPT=$(mem_kb SwapTotal)"
  echo "SWAPF=$(mem_kb SwapFree)"
  echo "BATT=$(cat /sys/class/power_supply/battery/temp 2>/dev/null)"
  ct=""
  for z in /sys/class/thermal/thermal_zone*; do
    [ -d "$z" ] || continue
    t=$(cat "$z/type" 2>/dev/null)
    case "$t" in
      *cpu*|*CPU*|*soc*|*SOC*|*mtktscpu*|*tsens_tz_sensor*)
        ct=$(cat "$z/temp" 2>/dev/null); break ;;
    esac
  done
  echo "CPUT=$ct"
  echo "LOAD=$(cut -d' ' -f1 /proc/loadavg 2>/dev/null)"
  echo "CORES=$(ls -d /sys/devices/system/cpu/cpu[0-9]* 2>/dev/null | wc -l)"
  d=$(df -k /data 2>/dev/null | tail -n 1 | tr -s ' ')
  echo "STOT=$(echo "$d" | cut -d' ' -f2)"
  echo "SUSE=$(echo "$d" | cut -d' ' -f3)"
  i=0
  for p in /sys/devices/system/cpu/cpufreq/policy*; do
    [ -d "$p" ] || continue
    echo "F$i=$(cat $p/scaling_cur_freq 2>/dev/null)/$(cat $p/cpuinfo_max_freq 2>/dev/null)"
    i=$((i+1))
  done
}

case "$1" in
  apply)     apply_all ;;
  boot)      boot_all ;;
  reset)     reset_all ;;
  info)      info ;;
  stat)      stat_all ;;
  hzlist)    hz_list ;;
  junk)      junk_clean ;;
  ramclean)  sync; echo 3 > /proc/sys/vm/drop_caches 2>/dev/null ;;
  killbg)    am kill-all ;;
  trimcache) pm trim-caches 999G ;;
  fstrim)    do_fstrim; exit 0 ;;
  dexopt)    nohup cmd package bg-dexopt-job >/dev/null 2>&1 & exit 0 ;;
  *)         echo "pakai: tweaks.sh apply|boot|reset|info|stat|hzlist|ramclean|killbg|trimcache|fstrim|dexopt|junk" ;;
esac