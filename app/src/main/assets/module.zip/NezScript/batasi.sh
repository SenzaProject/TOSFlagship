#!/system/bin/sh
DIR=/data/adb/nez_noapps
LIST=$DIR/daftar.txt
APPLIED=$DIR/diterapkan.txt
mkdir -p "$DIR"
touch "$LIST" "$APPLIED"

HOME_PKG=$(cmd package resolve-activity --brief -c android.intent.category.HOME \
  -a android.intent.action.MAIN 2>/dev/null | tail -n 1 | cut -d/ -f1)
IME_PKG=$(settings get secure default_input_method 2>/dev/null | cut -d/ -f1)

protected() {
  case "$1" in
    android|com.android.systemui*|com.android.phone*|com.android.server.telecom*|\
    com.android.providers.*|com.android.settings*|com.android.bluetooth*|com.android.nfc*|\
    com.android.shell*|com.android.inputmethod*|com.android.permissioncontroller*|\
    com.android.packageinstaller*|com.android.vending*|com.android.webview*|\
    com.google.android.gms*|com.google.android.gsf*|com.google.android.permissioncontroller*|\
    com.google.android.packageinstaller*|com.google.android.webview*|\
    com.google.android.inputmethod*|me.weishu.kernelsu*|com.topjohnwu.magisk*|\
    com.rifsxd.ksunext*|com.sukisu*|com.mediatek.*|com.qualcomm.*|com.sprd.*|com.unisoc.*)
      return 0 ;;
  esac
  [ -n "$HOME_PKG" ] && [ "$1" = "$HOME_PKG" ] && return 0
  [ -n "$IME_PKG" ] && [ "$1" = "$IME_PKG" ] && return 0
  return 1
}

while read -r pkg; do
  [ -z "$pkg" ] && continue
  grep -qx "$pkg" "$LIST" && continue
  cmd appops set --user 0 "$pkg" RUN_IN_BACKGROUND default
  cmd appops set --user 0 "$pkg" RUN_ANY_IN_BACKGROUND default
  am set-standby-bucket "$pkg" active
done < "$APPLIED"

while read -r pkg; do
  [ -z "$pkg" ] && continue
  protected "$pkg" && continue
  pm path "$pkg" >/dev/null 2>&1 || continue
  cmd appops set --user 0 "$pkg" RUN_IN_BACKGROUND ignore
  cmd appops set --user 0 "$pkg" RUN_ANY_IN_BACKGROUND ignore
  am set-standby-bucket "$pkg" restricted
  am force-stop "$pkg"
done < "$LIST"

cp -f "$LIST" "$APPLIED"