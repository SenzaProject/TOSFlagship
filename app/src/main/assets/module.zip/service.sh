#!/system/bin/sh
MODDIR=${0%/*}
LOG=$MODDIR/service.log
FLAG=/data/adb/nez_noapps/dynbar_off

#NezukaService
PATTERN="hotseat"
[ -f "$FLAG" ] || PATTERN="dynamicbar|hotseat"

while [ "$(getprop sys.boot_completed)" != "1" ]; do
  sleep 2
done
sleep 10

echo "$(date) - boot selesai" > "$LOG"

sh "$MODDIR/NezScript/batasi.sh" >> "$LOG" 2>&1
sh "$MODDIR/NezScript/tweaks.sh" boot >> "$LOG" 2>&1
( sleep 60; sh "$MODDIR/NezScript/tweaks.sh" apply >> "$LOG" 2>&1 ) &
hapus_cache() {
  local pkg="$1" dir
  [ -z "$pkg" ] && return
  for dir in /data/data/$pkg /data/user/0/$pkg /data/user_de/0/$pkg; do
    [ -d "$dir" ] || continue
    rm -rf "$dir/cache/"* "$dir/code_cache/"* 2>/dev/null
  done
  echo "$(date) - cache dihapus: $pkg" >> "$LOG"
}

LAUNCHER=$(cmd package resolve-activity --brief -c android.intent.category.HOME \
  -a android.intent.action.MAIN 2>/dev/null | tail -n 1 | cut -d/ -f1)

hapus_cache "$LAUNCHER"
hapus_cache "com.android.systemui"

overlay_nonaktif() {
  cmd overlay list --user 0 2>/dev/null \
    | grep -i -E "^\[ \] .*($PATTERN)" \
    | sed 's/^\[ \] *//'
}

n=1
while [ $n -le 5 ]; do
  LIST=$(overlay_nonaktif)
  [ -z "$LIST" ] && break

  for pkg in $LIST; do
    cmd overlay enable --user 0 "$pkg" >/dev/null 2>&1
    echo "$(date) - percobaan $n: enable $pkg" >> "$LOG"
  done

  sleep 5
  n=$((n+1))
done

if [ -z "$(overlay_nonaktif)" ]; then
  echo "$(date) - semua overlay aktif" >> "$LOG"
else
  echo "$(date) - masih ada overlay nonaktif:" >> "$LOG"
  overlay_nonaktif >> "$LOG"
fi